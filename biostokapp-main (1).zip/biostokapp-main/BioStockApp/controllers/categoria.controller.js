const conexao = require('../db');

// GET todas
exports.listarCategorias = (req, res) => {
  conexao.query('SELECT * FROM Categoria', (erro, resultados) => {
    if (erro) return res.status(500).json({ erro: erro.message });
    res.json(resultados);
  });
};

// POST nova categoria
exports.criarCategoria = (req, res) => {
  const { nmCategoria, status } = req.body;
  const sql = 'INSERT INTO Categoria (nmCategoria, status) VALUES (?, ?)';
  conexao.query(sql, [nmCategoria, status], (erro, resultado) => {
    if (erro) return res.status(500).json({ erro: erro.message });
    res.status(201).json({ mensagem: 'Categoria criada', id: resultado.insertId });
  });
};

// PUT atualizar
exports.atualizarCategoria = (req, res) => {
  const id = req.params.id;
  const { nmCategoria, status } = req.body;
  const sql = 'UPDATE Categoria SET nmCategoria = ?, status = ? WHERE idCategoria = ?';
  conexao.query(sql, [nmCategoria, status, id], (erro, resultado) => {
    if (erro) return res.status(500).json({ erro: erro.message });
    if (resultado.affectedRows === 0) return res.status(404).json({ erro: 'Categoria não encontrada' });
    res.json({ mensagem: 'Categoria atualizada' });
  });
};

// DELETE
exports.deletarCategoria = (req, res) => {
  const id = req.params.id;
  const sql = 'DELETE FROM Categoria WHERE idCategoria = ?';
  conexao.query(sql, [id], (erro, resultado) => {
    if (erro) return res.status(500).json({ erro: erro.message });
    if (resultado.affectedRows === 0) return res.status(404).json({ erro: 'Categoria não encontrada' });
    res.json({ mensagem: 'Categoria deletada' });
  });
};