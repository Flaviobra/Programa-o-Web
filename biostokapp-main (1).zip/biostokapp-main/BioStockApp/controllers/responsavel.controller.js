const conexao = require('../db');

exports.listarResponsaveis = (req, res) => {
  const sql = 'SELECT * FROM Responsavel';
  conexao.query(sql, (erro, resultados) => {
    if (erro) return res.status(500).json({ erro: erro.message });
    res.json(resultados);
  });
};

exports.criarResponsavel = (req, res) => {
  const { nmResponsavel, nmEmail, nrTelefone, status } = req.body;
  console.log("Recebido no backend:", req.body); // ADICIONE ISSO

  const sql = 'INSERT INTO Responsavel (nmResponsavel, nmEmail, nrTelefone, status) VALUES (?, ?, ?, ?)';
  conexao.query(sql, [nmResponsavel, nmEmail, nrTelefone, status], (erro, resultado) => {
    if (erro) {
      console.error("Erro ao inserir no banco:", erro); // ADICIONE ISSO
      return res.status(500).json({ erro: erro.message });
    }
    res.status(201).json({ mensagem: 'Responsável criado', id: resultado.insertId });
  });
};

exports.atualizarResponsavel = (req, res) => {
  const id = req.params.id;
  console.log('Atualizar responsável id:', id);
  console.log('Dados recebidos:', req.body);
  const { nmResponsavel, nmEmail, nrTelefone, status } = req.body;

  const sql = 'UPDATE Responsavel SET nmResponsavel = ?, nmEmail = ?, nrTelefone = ?, status = ? WHERE idResponsavel = ?';
  conexao.query(sql, [nmResponsavel, nmEmail, nrTelefone, status, id], (erro, resultado) => {
    if (erro) {
      console.error('Erro ao atualizar:', erro);
      return res.status(500).json({ erro: erro.message });
    }
    if (resultado.affectedRows === 0) return res.status(404).json({ erro: 'Responsável não encontrado' });
    res.json({ mensagem: 'Responsável atualizado' });
  });
};

exports.deletarResponsavel = (req, res) => {
  const id = req.params.id;
  const sql = 'DELETE FROM Responsavel WHERE idResponsavel = ?';
  conexao.query(sql, [id], (erro, resultado) => {
    if (erro) return res.status(500).json({ erro: erro.message });
    if (resultado.affectedRows === 0) return res.status(404).json({ erro: 'Responsável não encontrado' });
    res.json({ mensagem: 'Responsável deletado' });
  });
};