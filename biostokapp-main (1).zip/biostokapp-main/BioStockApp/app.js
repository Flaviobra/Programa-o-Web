const express = require('express');
const cors = require('cors'); // ← importe o CORS

const app = express();

// Habilite o CORS para permitir requisições do React (porta 5173)
app.use(cors({
  origin: 'http://localhost:5173', // ou use "*" se quiser liberar geral
  methods: ['GET', 'POST', 'PUT', 'DELETE'],
  credentials: true
}));

app.use(express.json());

// Rotas
const produtoRoutes = require('./routes/produto.routes');
const responsavelRoutes = require('./routes/responsavel.routes');
const categoriaRoutes = require('./routes/categoria.routes');
const localizacaoRoutes = require('./routes/localizacao.routes');
const usuarioRoutes = require('./routes/usuario.routes');

app.use('/produtos', produtoRoutes);
app.use('/responsaveis', responsavelRoutes);
app.use('/categorias', categoriaRoutes);
app.use('/localizacoes', localizacaoRoutes);
app.use('/usuarios', usuarioRoutes);

// Porta
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});