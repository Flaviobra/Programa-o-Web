import React, { useEffect, useState } from 'react';
import CategoriaForm from '../components/CategoriaForm';
import CategoriaList from '../components/CategoriaList';
import {
  getCategorias,
  createCategoria,
  updateCategoria,
  deleteCategoria,
} from '../services/categoriaService';

const CategoriaPage = () => {
  const [categorias, setCategorias] = useState([]);
  const [categoriaSelecionada, setCategoriaSelecionada] = useState(null);

  const carregarCategorias = async () => {
    try {
      const resposta = await getCategorias();
      setCategorias(resposta.data);
    } catch (erro) {
      console.error('Erro ao carregar categorias:', erro);
    }
  };

  const adicionarOuAtualizarCategoria = async (categoria) => {
    try {
      if (categoriaSelecionada) {
        await updateCategoria(categoriaSelecionada.idCategoria, categoria);
        setCategoriaSelecionada(null);
      } else {
        await createCategoria(categoria);
      }
      carregarCategorias();
    } catch (erro) {
      console.error('Erro ao salvar categoria:', erro);
    }
  };

  const editarCategoria = (categoria) => {
    setCategoriaSelecionada(categoria);
  };

  const excluirCategoria = async (id) => {
    if (!window.confirm("Tem certeza que deseja excluir esta categoria?")) return;
    try {
      await deleteCategoria(id);
      carregarCategorias();
    } catch (erro) {
      console.error('Erro ao excluir categoria:', erro);
    }
  };

  useEffect(() => {
    carregarCategorias();
  }, []);

  return (
    <div>
      <h2>Cadastro de Categorias</h2>
      <CategoriaForm
        onSubmit={adicionarOuAtualizarCategoria}
        initialData={categoriaSelecionada}
      />
      <CategoriaList
        categorias={categorias}
        onEdit={editarCategoria}
        onDelete={excluirCategoria}
      />
    </div>
  );
};

export default CategoriaPage;