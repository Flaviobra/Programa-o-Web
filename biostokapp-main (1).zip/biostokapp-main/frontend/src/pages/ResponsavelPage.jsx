import React, { useEffect, useState } from 'react';
import ResponsavelForm from '../components/ResponsavelForm';
import ResponsavelList from '../components/ResponsavelList';
import {
  getResponsaveis,
  createResponsavel,
  updateResponsavel,
  deleteResponsavel
} from '../services/responsavelService';

const ResponsavelPage = () => {
  const [responsaveis, setResponsaveis] = useState([]);
  const [responsavelSelecionado, setResponsavelSelecionado] = useState(null);

  const carregarResponsaveis = async () => {
    try {
      const resposta = await getResponsaveis();
      setResponsaveis(resposta.data);
    } catch (erro) {
      console.error('Erro ao carregar responsáveis:', erro);
    }
  };

 const salvarResponsavel = async (dados) => {
  try {
    console.log('Salvando responsável:', responsavelSelecionado, dados);
    if (responsavelSelecionado) {
      await updateResponsavel(responsavelSelecionado.idResponsavel, dados);
      setResponsavelSelecionado(null);
    } else {
      await createResponsavel(dados);
    }
    carregarResponsaveis();
  } catch (erro) {
    console.error('Erro ao salvar responsável:', erro);
  }
};

  const editarResponsavel = (r) => {
    setResponsavelSelecionado(r);
  };

const excluirResponsavel = async (id) => {
  if (!window.confirm("Tem certeza que deseja excluir este responsável?")) return;

  try {
    console.log('Excluindo responsável:', id);
    await deleteResponsavel(id);
    carregarResponsaveis();
  } catch (erro) {
    console.error('Erro ao excluir responsável:', erro);
  }
};


  useEffect(() => {
    carregarResponsaveis();
  }, []);

  return (
    <div>
      <h2>Cadastro de Responsáveis</h2>
      <ResponsavelForm onSubmit={salvarResponsavel} initialData={responsavelSelecionado} />
      <ResponsavelList
        responsaveis={responsaveis}
        onEdit={editarResponsavel}
        onDelete={excluirResponsavel}
      />
    </div>
  );
};

export default ResponsavelPage;