// src/pages/UsuarioPage.jsx
import React, { useEffect, useState } from "react";
import axios from "axios";
import UsuarioForm from "../components/UsuarioForm";

const UsuarioPage = () => {
  const [usuarios, setUsuarios] = useState([]);
  const [editando, setEditando] = useState(null);

  // Carrega a lista de usuários
  const fetchUsuarios = async () => {
    try {
      const response = await axios.get("http://localhost:3000/usuarios");
      setUsuarios(response.data);
    } catch (error) {
      console.error("Erro ao carregar usuários:", error);
    }
  };

  useEffect(() => {
    fetchUsuarios();
  }, []);

  // Envia novo usuário ou atualização
  const handleSubmit = async (formData) => {
    try {
      if (editando) {
        await axios.put(`http://localhost:3000/usuarios/${editando.idUsuario}`, formData);
      } else {
        await axios.post("http://localhost:3000/usuarios", formData);
      }
      setEditando(null);
      fetchUsuarios();
    } catch (error) {
      console.error("Erro ao salvar usuário:", error);
      alert("Erro ao salvar. Veja o console.");
    }
  };

  // Prepara edição
  const handleEdit = (usuario) => {
    setEditando(usuario);
  };

  // Exclui usuário
  const handleDelete = async (id) => {
    if (!window.confirm("Tem certeza que deseja excluir este usuário?")) return;
    try {
      await axios.delete(`http://localhost:3000/usuarios/${id}`);
      fetchUsuarios();
    } catch (error) {
      console.error("Erro ao excluir usuário:", error);
    }
  };

  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-4">
        {editando ? "Editar Usuário" : "Cadastrar Usuário"}
      </h2>

      <UsuarioForm
        onSubmit={handleSubmit}
        editando={editando}
        onCancel={() => setEditando(null)}
      />

      <h2 className="text-xl font-semibold mt-8 mb-2">Lista de Usuários</h2>
      <table className="w-full border-collapse border">
        <thead className="bg-gray-200">
          <tr>
            <th className="border px-2 py-1">ID</th>
            <th className="border px-2 py-1">Nome</th>
            <th className="border px-2 py-1">Email</th>
            <th className="border px-2 py-1">Login</th>
            <th className="border px-2 py-1">Status</th>
            <th className="border px-2 py-1">Ações</th>
          </tr>
        </thead>
        <tbody>
          {usuarios.map((user) => (
            <tr key={user.idUsuario} className="hover:bg-gray-100">
              <td className="border px-2 py-1">{user.idUsuario}</td>
              <td className="border px-2 py-1">{user.nmUsuario}</td>
              <td className="border px-2 py-1">{user.nmEmail}</td>
              <td className="border px-2 py-1">{user.nmLogin}</td>
              <td className="border px-2 py-1 capitalize">{user.status}</td>
              <td className="border px-2 py-1 space-x-2">
                <button onClick={() => handleEdit(user)} className="text-blue-600 hover:underline">Editar</button>
                <button onClick={() => handleDelete(user.idUsuario)} className="text-red-600 hover:underline">Excluir</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default UsuarioPage;
