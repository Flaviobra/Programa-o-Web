import React, { useEffect, useState } from "react";
import ProdutoForm from "../components/ProdutoForm";
import axios from "axios";
import * as XLSX from "xlsx";
import { saveAs } from "file-saver";

const ProdutoPage = () => {
  const [produtos, setProdutos] = useState([]);
  const [formData, setFormData] = useState({
    nmProduto: "",
    nmPreço: "",
    qtProduto: "",
    dtCadastro: "",
    idResponsavel: "",
    idCategoria: "",
    idLocalizacao: "",
    idUsuario: "",
  });
  const [editandoId, setEditandoId] = useState(null);

  // Listas para selects
  const [responsaveis, setResponsaveis] = useState([]);
  const [categorias, setCategorias] = useState([]);
  const [localizacoes, setLocalizacoes] = useState([]);
  const [usuarios, setUsuarios] = useState([]);

  // Buscar dados para selects
  const fetchDadosAuxiliares = async () => {
    try {
      const [respRes, respCat, respLoc, respUser] = await Promise.all([
        axios.get("http://localhost:3000/responsaveis"),
        axios.get("http://localhost:3000/categorias"),
        axios.get("http://localhost:3000/localizacoes"),
        axios.get("http://localhost:3000/usuarios"),
      ]);
      setResponsaveis(respRes.data);
      setCategorias(respCat.data);
      setLocalizacoes(respLoc.data);
      setUsuarios(respUser.data);
    } catch (error) {
      console.error("Erro ao carregar dados auxiliares:", error);
    }
  };

  // Buscar produtos
  const fetchProdutos = async () => {
    try {
      const response = await axios.get("http://localhost:3000/produtos");
      setProdutos(response.data);
    } catch (error) {
      console.error("Erro ao carregar produtos:", error);
    }
  };

  useEffect(() => {
    fetchDadosAuxiliares();
    fetchProdutos();
  }, []);

  // Atualizar dados do formulário
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  // Submeter formulário (inserir ou atualizar)
  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      if (editandoId) {
        // Atualizar
        await axios.put(`http://localhost:3000/produtos/${editandoId}`, formData);
      } else {
        // Criar
        await axios.post("http://localhost:3000/produtos", formData);
      }
      setFormData({
        nmProduto: "",
        nmPreço: "",
        qtProduto: "",
        dtCadastro: "",
        idResponsavel: "",
        idCategoria: "",
        idLocalizacao: "",
        idUsuario: "",
      });
      setEditandoId(null);
      fetchProdutos();
    } catch (error) {
      console.error("Erro ao salvar produto:", error);
      alert("Erro ao salvar produto. Veja o console para detalhes.");
    }
  };

  // Editar produto: carrega dados no formulário
  const handleEdit = (produto) => {
    setFormData({
      nmProduto: produto.nmProduto,
      nmPreço: produto.nmPreço,
      qtProduto: produto.qtProduto,
      dtCadastro: produto.dtCadastro ? produto.dtCadastro.split("T")[0] : "",
      idResponsavel: produto.idResponsavel,
      idCategoria: produto.idCategoria,
      idLocalizacao: produto.idLocalizacao,
      idUsuario: produto.idUsuario,
    });
    setEditandoId(produto.idProduto);
  };

  // Cancelar edição
  const handleCancel = () => {
    setFormData({
      nmProduto: "",
      nmPreço: "",
      qtProduto: "",
      dtCadastro: "",
      idResponsavel: "",
      idCategoria: "",
      idLocalizacao: "",
      idUsuario: "",
    });
    setEditandoId(null);
  };

  // Excluir produto
  const handleDelete = async (id) => {
    if (!window.confirm("Tem certeza que deseja excluir este produto?")) return;

    try {
      await axios.delete(`http://localhost:3000/produtos/${id}`);
      fetchProdutos();
    } catch (error) {
      console.error("Erro ao excluir produto:", error);
      alert("Erro ao excluir produto. Veja o console para detalhes.");
    }
  };
  
  const exportarEstoque = () => {
  // Mapeia os produtos para um formato legível
  const dadosRelatorio = produtos.map((p) => ({
    "Nome do Produto": p.nmProduto,
    "Preço": p.nmPreço,
    "Quantidade": p.qtProduto,
    "Data de Cadastro": p.dtCadastro?.split("T")[0],
    "Responsável": responsaveis.find(r => r.idResponsavel === p.idResponsavel)?.nmResponsavel || "",
    "Categoria": categorias.find(c => c.idCategoria === p.idCategoria)?.nmCategoria || "",
    "Localização": localizacoes.find(l => l.idLocalizacao === p.idLocalizacao)?.nmLocalizacao || "",
    "Usuário": usuarios.find(u => u.idUsuario === p.idUsuario)?.nmUsuario || "",
  }));

  const worksheet = XLSX.utils.json_to_sheet(dadosRelatorio);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, "EstoqueAtual");

  const excelBuffer = XLSX.write(workbook, { bookType: "xlsx", type: "array" });
  const blob = new Blob([excelBuffer], { type: "application/octet-stream" });
  saveAs(blob, "relatorio_estoque_atual.xlsx");
};

const ajustarQuantidade = async (produto, delta) => {
  const novaQuantidade = produto.qtProduto + delta;
  if (novaQuantidade < 0) return alert("Quantidade não pode ser negativa.");

  try {
    await axios.put(`http://localhost:3000/produtos/${produto.idProduto}`, {
      ...produto,
      qtProduto: novaQuantidade,
    });
    fetchProdutos();
  } catch (error) {
    console.error("Erro ao ajustar quantidade:", error);
    alert("Erro ao ajustar quantidade.");
  }
};
  return (
    <div>
      <h2>{editandoId ? "Editar Produto" : "Cadastrar Produto"}</h2>
      <ProdutoForm
        formData={formData}
        handleChange={handleChange}
        handleSubmit={handleSubmit}
        handleCancel={handleCancel}
        responsaveis={responsaveis}
        categorias={categorias}
        localizacoes={localizacoes}
        usuarios={usuarios}
      />

      <h2>Lista de Produtos</h2>
            <button
        onClick={exportarEstoque}
        className="bg-blue-600 text-white px-4 py-2 rounded mb-4"
        >
        Exportar Relatório de Estoque
        </button>
      {produtos.length === 0 ? (
        <p>Nenhum produto cadastrado.</p>
      ) : (
        <table border="1" cellPadding="8" style={{ marginTop: "1rem" }}>
          <thead>
            <tr>
              <th>ID</th>
              <th>Nome</th>
              <th>Preço</th>
              <th>Quantidade</th>
              <th>Data Cadastro</th>
              <th>Responsável</th>
              <th>Categoria</th>
              <th>Localização</th>
              <th>Usuário</th>
              <th>Ações</th>
            </tr>
          </thead>
          <tbody>
            {produtos.map((produto) => (
              <tr key={produto.idProduto}>
                <td>{produto.idProduto}</td>
                <td>{produto.nmProduto}</td>
                <td>{produto.nmPreço}</td>
                <td>{produto.qtProduto}</td>
                <td>{produto.dtCadastro ? produto.dtCadastro.split("T")[0] : ""}</td>
                <td>{responsaveis.find((r) => r.idResponsavel === produto.idResponsavel)?.nmResponsavel || "—"}</td>
                <td>{categorias.find((c) => c.idCategoria === produto.idCategoria)?.nmCategoria || "—"}</td>
                <td>{localizacoes.find((l) => l.idLocalizacao === produto.idLocalizacao)?.nmLocalizacao || "—"}</td>
                <td>{usuarios.find((u) => u.idUsuario === produto.idUsuario)?.nmUsuario || "—"}</td>
                <td>
                <div class="grid grid-cols-[1fr_auto_auto]"> <button onClick={() => handleEdit(produto)} className="text-blue-600 hover:underline">Editar</button>
                <button onClick={() => handleDelete(produto.idProduto)} className="text-red-600 hover:underline">Excluir</button>
                <button onClick={() => ajustarQuantidade(produto, 1)} className="text-green-600 hover:underline">Adicionar</button>
                <button onClick={() => ajustarQuantidade(produto, -1)} className="text-yellow-600 hover:underline">Remover</button>
                </div>
                 </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default ProdutoPage;
