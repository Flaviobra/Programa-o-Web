import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link } from "react-router-dom";

const LocalizacaoPage = () => {
  const [localizacoes, setLocalizacoes] = useState([]);
  const [formData, setFormData] = useState({
    nmLocalizacao: "",
    dsLocalizacao: "",
  });
  const [editandoId, setEditandoId] = useState(null);

  useEffect(() => {
    fetchLocalizacoes();
  }, []);

  const fetchLocalizacoes = async () => {
    try {
      const response = await axios.get("http://localhost:3000/localizacoes");
      setLocalizacoes(response.data);
    } catch (error) {
      console.error("Erro ao carregar localizações:", error);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editandoId) {
        await axios.put(`http://localhost:3000/localizacoes/${editandoId}`, formData);
      } else {
        await axios.post("http://localhost:3000/localizacoes", formData);
      }
      setFormData({ nmLocalizacao: "", dsLocalizacao: "" });
      setEditandoId(null);
      fetchLocalizacoes();
    } catch (error) {
      console.error("Erro ao salvar localização:", error);
    }
  };

  const handleEdit = (localizacao) => {
    setFormData({
      nmLocalizacao: localizacao.nmLocalizacao,
      dsLocalizacao: localizacao.dsLocalizacao,
    });
    setEditandoId(localizacao.idLocalizacao);
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Deseja excluir esta localização?")) return;
    try {
      await axios.delete(`http://localhost:3000/localizacoes/${id}`);
      fetchLocalizacoes();
    } catch (error) {
      console.error("Erro ao excluir localização:", error);
    }
  };

  return (
    <div className="p-6">


      <h2 className="text-2xl font-bold mb-4">
        {editandoId ? "Editar Localização" : "Cadastrar Localização"}
      </h2>

      <form onSubmit={handleSubmit} className="space-y-4 bg-white p-4 shadow rounded max-w-md">
        <input
          type="text"
          name="nmLocalizacao"
          placeholder="Nome da Localização"
          className="w-full border rounded p-2"
          value={formData.nmLocalizacao}
          onChange={handleChange}
          required
        />
        <input
          type="text"
          name="dsLocalizacao"
          placeholder="Descrição"
          className="w-full border rounded p-2"
          value={formData.dsLocalizacao}
          onChange={handleChange}
          required
        />
        <div className="flex gap-2">
          <button type="submit" className="bg-green-600 text-white px-4 py-2 rounded">
            Salvar
          </button>
          {editandoId && (
            <button type="button" onClick={() => setEditandoId(null)} className="bg-gray-400 text-white px-4 py-2 rounded">
              Cancelar
            </button>
          )}
        </div>
      </form>

      <h2 className="text-xl font-semibold mt-8 mb-2">Lista de Localizações</h2>
      <table className="w-full border-collapse border">
        <thead className="bg-gray-200">
          <tr>
            <th className="border px-2 py-1">ID</th>
            <th className="border px-2 py-1">Nome</th>
            <th className="border px-2 py-1">Descrição</th>
            <th className="border px-2 py-1">Ações</th>
          </tr>
        </thead>
        <tbody>
          {localizacoes.map((loc) => (
            <tr key={loc.idLocalizacao} className="hover:bg-gray-100">
              <td className="border px-2 py-1">{loc.idLocalizacao}</td>
              <td className="border px-2 py-1">{loc.nmLocalizacao}</td>
              <td className="border px-2 py-1">{loc.dsLocalizacao}</td>
              <td className="border px-2 py-1 space-x-2">
                <button onClick={() => handleEdit(loc)} className="text-blue-600 hover:underline">Editar</button>
                <button onClick={() => handleDelete(loc.idLocalizacao)} className="text-red-600 hover:underline">Excluir</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default LocalizacaoPage;
