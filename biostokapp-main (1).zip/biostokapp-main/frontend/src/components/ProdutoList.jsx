import React from 'react';

export default function ProdutoList({ produtos, onEdit, onDelete }) {
  return (
    <ul>
      {produtos.map((produto) => (
        <li key={produto.idProduto}>
          {produto.nmProduto} - {produto.nmPreço} - {produto.qtProduto}
          <button onClick={() => onEdit(produto)}>Editar</button>
          <button onClick={() => onDelete(produto.idProduto)}>Excluir</button>
        </li>
      ))}
    </ul>
  );
}
