import React from 'react';

const ResponsavelList = ({ responsaveis, onEdit, onDelete }) => {
  return (
    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>Nome</th>
          <th>Email</th>
          <th>Telefone</th>
          <th>Status</th>
          <th>Ações</th>
        </tr>
      </thead>
      <tbody>
        {responsaveis.map((r) => (
          <tr key={r.idResponsavel}>
            <td>{r.idResponsavel}</td>
            <td>{r.nmResponsavel}</td>
            <td>{r.nmEmail}</td>
            <td>{r.nrTelefone}</td>
            <td>{r.status}</td>
            <td>
              <button onClick={() => onEdit(r)}>Editar</button>
              <button onClick={() => onDelete(r.idResponsavel)}>Excluir</button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
};

export default ResponsavelList;