import React, { useState, useEffect } from 'react';

const LocalizacaoForm = ({ localizacaoEditando, onSalvar }) => {
  const [localizacao, setLocalizacao] = useState({
    nmLocalizacao: '',
    dsLocalizacao: ''
  });

  useEffect(() => {
    if (localizacaoEditando) {
      setLocalizacao(localizacaoEditando);
    }
  }, [localizacaoEditando]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setLocalizacao((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSalvar(localizacaoEditando?.idLocalizacao || null, localizacao);
    setLocalizacao({ nmLocalizacao: '', dsLocalizacao: '' });
  };

  return (
    <form onSubmit={handleSubmit}>
      <input name="nmLocalizacao" value={localizacao.nmLocalizacao} onChange={handleChange} placeholder="Nome" required />
      <input name="dsLocalizacao" value={localizacao.dsLocalizacao} onChange={handleChange} placeholder="Descrição" required />
      <button type="submit">Salvar</button>
    </form>
  );
};

export default LocalizacaoForm;