import React, { useState, useEffect } from 'react';

const CategoriaForm = ({ onSubmit, initialData }) => {
  const [form, setForm] = useState({ nmCategoria: '', status: 'ativo' });

  useEffect(() => {
    if (initialData) setForm(initialData);
  }, [initialData]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(form);
    setForm({ nmCategoria: '', status: 'ativo' });
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        type="text"
        name="nmCategoria"
        value={form.nmCategoria}
        onChange={handleChange}
        placeholder="Nome da categoria"
        required
      />
      <select name="status" value={form.status} onChange={handleChange}>
        <option value="ativo">Ativo</option>
        <option value="inativo">Inativo</option>
      </select>
      <button type="submit">Salvar</button>
    </form>
  );
};

export default CategoriaForm;