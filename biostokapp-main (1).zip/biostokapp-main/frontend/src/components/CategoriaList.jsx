import React from 'react';

const CategoriaList = ({ categorias, onEdit, onDelete }) => {
  return (
    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>Nome</th>
          <th>Status</th>
          <th>Ações</th>
        </tr>
      </thead>
      <tbody>
        {categorias.map((categoria) => (
          <tr key={categoria.idCategoria}>
            <td>{categoria.idCategoria}</td>
            <td>{categoria.nmCategoria}</td>
            <td>{categoria.status}</td>
            <td>
              <button onClick={() => onEdit(categoria)}>Editar</button>
              <button onClick={() => onDelete(categoria.idCategoria)}>Excluir</button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
};

export default CategoriaList;