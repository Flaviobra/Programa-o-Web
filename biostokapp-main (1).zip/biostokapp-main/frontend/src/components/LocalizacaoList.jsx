import React from 'react';

const LocalizacaoList = ({ localizacoes, onEditar, onExcluir }) => (
  <ul>
    {localizacoes.map((loc) => (
      <li key={loc.idLocalizacao}>
        {loc.nmLocalizacao} - {loc.dsLocalizacao}
        <button onClick={() => onEditar(loc)}>Editar</button>
        <button onClick={() => onExcluir(loc.idLocalizacao)}>Excluir</button>
      </li>
    ))}
  </ul>
);

export default LocalizacaoList;