import React from "react";

const ProdutoForm = ({
  formData,
  handleChange,
  handleSubmit,
  handleCancel,
  responsaveis,
  categorias,
  localizacoes,
  usuarios,
}) => {
  return (
    <form onSubmit={handleSubmit}>
      <div>
        <label>Nome do Produto:</label>
        <input
          type="text"
          name="nmProduto"
          value={formData.nmProduto || ""}
          onChange={handleChange}
          required
        />
      </div>

      <div>
        <label>Preço:</label>
        <input
          type="text"
          name="nmPreço"
          value={formData.nmPreço || ""}
          onChange={handleChange}
          required
        />
      </div>

      <div>
        <label>Quantidade:</label>
        <input
          type="number"
          name="qtProduto"
          value={formData.qtProduto || ""}
          onChange={handleChange}
          required
        />
      </div>

      <div>
        <label>Data de Cadastro:</label>
        <input
          type="date"
          name="dtCadastro"
          value={formData.dtCadastro || ""}
          onChange={handleChange}
          required
        />
      </div>

      <div>
        <label>Responsável:</label>
        <select
          name="idResponsavel"
          value={formData.idResponsavel || ""}
          onChange={handleChange}
          required
        >
          <option value="">Selecione</option>
          {responsaveis.map((resp) => (
            <option key={resp.idResponsavel} value={resp.idResponsavel}>
              {resp.nmResponsavel}
            </option>
          ))}
        </select>
      </div>

      <div>
        <label>Categoria:</label>
        <select
          name="idCategoria"
          value={formData.idCategoria || ""}
          onChange={handleChange}
          required
        >
          <option value="">Selecione</option>
          {categorias.map((cat) => (
            <option key={cat.idCategoria} value={cat.idCategoria}>
              {cat.nmCategoria}
            </option>
          ))}
        </select>
      </div>

      <div>
        <label>Localização:</label>
        <select
          name="idLocalizacao"
          value={formData.idLocalizacao || ""}
          onChange={handleChange}
          required
        >
          <option value="">Selecione</option>
          {localizacoes.map((loc) => (
            <option key={loc.idLocalizacao} value={loc.idLocalizacao}>
              {loc.nmLocalizacao}
            </option>
          ))}
        </select>
      </div>

      <div>
        <label>Usuário:</label>
        <select
          name="idUsuario"
          value={formData.idUsuario || ""}
          onChange={handleChange}
          required
        >
          <option value="">Selecione</option>
          {usuarios.map((user) => (
            <option key={user.idUsuario} value={user.idUsuario}>
              {user.nmUsuario}
            </option>
          ))}
        </select>
      </div>

      <div>
        <button type="submit">Salvar</button>
        <button type="button" onClick={handleCancel}>
          Cancelar
        </button>
      </div>
    </form>
  );
};


export default ProdutoForm;
