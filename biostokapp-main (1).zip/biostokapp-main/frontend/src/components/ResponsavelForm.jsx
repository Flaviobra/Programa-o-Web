import React, { useState, useEffect } from 'react';

const ResponsavelForm = ({ onSubmit, initialData }) => {
  const [form, setForm] = useState({
    nmResponsavel: '',
    nmEmail: '',
    nrTelefone: '',
    status: 'ativo'
  });

  useEffect(() => {
    if (initialData) {
      setForm({
        nmResponsavel: initialData.nmResponsavel ?? '',
        nmEmail: initialData.nmEmail ?? '',
        nrTelefone: initialData.nrTelefone ?? '',
        status: initialData.status ?? 'ativo'
      });
    } else {
      // Limpa o formulário ao remover initialData
      setForm({
        nmResponsavel: '',
        nmEmail: '',
        nrTelefone: '',
        status: 'ativo'
      });
    }
  }, [initialData]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(form);
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        type="text"
        name="nmResponsavel"
        placeholder="Nome"
        value={form.nmResponsavel}
        onChange={handleChange}
        required
      />
      <input
        type="email"
        name="nmEmail"
        placeholder="Email"
        value={form.nmEmail}
        onChange={handleChange}
      />
      <input
        type="text"
        name="nrTelefone"
        placeholder="Telefone"
        value={form.nrTelefone}
        onChange={handleChange}
      />
      <select name="status" value={form.status} onChange={handleChange}>
        <option value="ativo">Ativo</option>
        <option value="inativo">Inativo</option>
      </select>
      <button type="submit">Salvar</button>
    </form>
  );
};

export default ResponsavelForm;