// src/components/UsuarioForm.jsx
import { useState, useEffect } from 'react';

export default function UsuarioForm({ onSubmit, editando, onCancel }) {
  const [form, setForm] = useState({
    nmUsuario: '',
    nmEmail: '',
    nmLogin: '',
    nmSenha: '',
    status: 'ativo'
  });

  useEffect(() => {
    if (editando) {
      setForm(editando);
    } else {
      setForm({
        nmUsuario: '',
        nmEmail: '',
        nmLogin: '',
        nmSenha: '',
        status: 'ativo'
      });
    }
  }, [editando]);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(form);
    if (!editando) {
      setForm({ nmUsuario: '', nmEmail: '', nmLogin: '', nmSenha: '', status: 'ativo' });
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 bg-white p-4 shadow rounded max-w-md">
      <input
        name="nmUsuario"
        placeholder="Nome"
        value={form.nmUsuario}
        onChange={handleChange}
        className="w-full border rounded p-2"
        required
      />
      <input
        name="nmEmail"
        placeholder="Email"
        type="email"
        value={form.nmEmail}
        onChange={handleChange}
        className="w-full border rounded p-2"
        required
      />
      <input
        name="nmLogin"
        placeholder="Login"
        value={form.nmLogin}
        onChange={handleChange}
        className="w-full border rounded p-2"
        required
      />
      <input
        name="nmSenha"
        placeholder="Senha"
        type="password"
        value={form.nmSenha}
        onChange={handleChange}
        className="w-full border rounded p-2"
        required
      />
      <select
        name="status"
        value={form.status}
        onChange={handleChange}
        className="w-full border rounded p-2"
        required
      >
        <option value="ativo">Ativo</option>
        <option value="inativo">Inativo</option>
      </select>

      <div className="flex gap-2">
        <button type="submit" className="bg-green-600 text-white px-4 py-2 rounded">
          {editando ? 'Atualizar' : 'Cadastrar'}
        </button>
        {editando && (
          <button type="button" onClick={onCancel} className="bg-gray-400 text-white px-4 py-2 rounded">
            Cancelar
          </button>
        )}
      </div>
    </form>
  );
}
