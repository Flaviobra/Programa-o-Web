// src/components/UsuarioList.jsx
export default function UsuarioList({ usuarios }) {
  return (
    <div>
      <h2>Lista de Usuários</h2>
      <ul>
        {usuarios.map((usuario) => (
          <li key={usuario.idUsuario}>
            {usuario.nmUsuario} - {usuario.nmEmail} - {usuario.status}
          </li>
        ))}
      </ul>
    </div>
  );
}