import React from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import UsuarioPage from "./pages/UsuarioPage";
import CategoriaPage from "./pages/CategoriaPage";
import ResponsavelPage from "./pages/ResponsavelPage";
import LocalizacaoPage from "./pages/LocalizacaoPage";
import ProdutoPage from "./pages/ProdutoPage";

const App = () => {
  return (
    <Router>
      <nav style={styles.navbar}>
        <Link to="/" style={styles.link}>Produtos</Link>
        <Link to="/usuarios" style={styles.link}>Usuários</Link>
        <Link to="/categorias" style={styles.link}>Categorias</Link>
        <Link to="/responsaveis" style={styles.link}>Responsáveis</Link>
        <Link to="/localizacoes" style={styles.link}>Localizações</Link>
      </nav>
      <div style={styles.container}>
        <Routes>
          <Route path="/" element={<ProdutoPage />} />
          <Route path="/usuarios" element={<UsuarioPage />} />
          <Route path="/categorias" element={<CategoriaPage />} />
          <Route path="/responsaveis" element={<ResponsavelPage />} />
          <Route path="/localizacoes" element={<LocalizacaoPage />} />
        </Routes>
      </div>
    </Router>
  );
};

const styles = {
  navbar: {
    backgroundColor: "#0077cc",
    padding: "1rem",
    display: "flex",
    gap: "1rem",
    justifyContent: "center",
    position: "fixed",
    top: 0,
    width: "100%",
    zIndex: 1000,
  },
  link: {
    color: "#fff",
    textDecoration: "none",
    fontWeight: "bold",
  },
  container: {
    padding: "5rem 2rem 2rem", // deixa espaço para o menu fixo
  },
};

export default App;
