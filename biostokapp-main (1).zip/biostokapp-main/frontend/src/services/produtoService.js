import axios from 'axios';

const API = 'http://localhost:3000/produtos';

export const getProdutos = () => axios.get(API);
export const getProdutoById = (id) => axios.get(`${API}/${id}`);
export const createProduto = (produto) => axios.post(API, produto);
export const updateProduto = (id, produto) => axios.put(`${API}/${id}`, produto);
export const deleteProduto = (id) => axios.delete(`${API}/${id}`);