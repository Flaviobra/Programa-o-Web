import axios from 'axios';

const API_URL = 'http://localhost:3000/responsaveis';

export const getResponsaveis = () => axios.get(API_URL);
export const createResponsavel = (responsavel) => axios.post(API_URL, responsavel);
export const updateResponsavel = (id, responsavel) => axios.put(`${API_URL}/${id}`, responsavel);
export const deleteResponsavel = (id) => axios.delete(`${API_URL}/${id}`);