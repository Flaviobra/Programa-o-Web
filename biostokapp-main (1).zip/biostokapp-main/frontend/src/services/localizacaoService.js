import axios from 'axios';

const API_URL = 'http://localhost:3000/localizacoes';

export const getLocalizacoes = () => axios.get(API_URL);
export const createLocalizacao = (data) => axios.post(API_URL, data);
export const updateLocalizacao = (id, data) => axios.put(`${API_URL}/${id}`, data);
export const deleteLocalizacao = (id) => axios.delete(`${API_URL}/${id}`);